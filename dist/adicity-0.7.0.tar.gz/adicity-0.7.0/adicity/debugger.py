# import eel
import time
import os
from threading import Thread


on = False
token = None
go = False
level = 0
code = ""
delay = 0.1
tks = []
advance = False
currentoken = None
breakpoints = []
broke = True
